module.exports = require('./lib/duckdb');
